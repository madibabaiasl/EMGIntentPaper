import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.metrics import f1_score, precision_score, recall_score, confusion_matrix
import numpy as np
import pandas as pd
from torch.utils.data import DataLoader, TensorDataset

# Load the training dataset
file_path = 'normalized_emg_dataset.csv'
data = pd.read_csv(file_path)

# Split the features and target
X = data.drop(columns=['Target'])
y = data['Target']
y = y - 1  # Adjust target labels to be in the range [0, n_classes - 1]

# Apply feature selection on training data
select_kbest_anova = SelectKBest(score_func=f_classif, k=20)
X_selected = select_kbest_anova.fit_transform(X, y)  # Fit only on training data

# Standardize the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_selected)

# Convert to PyTorch tensors
X_tensor = torch.tensor(X_scaled, dtype=torch.float32)
y_tensor = torch.tensor(y.values, dtype=torch.long)

# Define Transformer + RNN (LSTM) Model
class TransformerRNNModel(nn.Module):
    def __init__(self, input_dim, n_classes, n_heads=2, ff_dim=64, num_layers=2, lstm_hidden_size=64, lstm_num_layers=2, dropout=0.4):
        super(TransformerRNNModel, self).__init__()
        
        # Transformer components
        self.input_layer = nn.Linear(input_dim, ff_dim)
        encoder_layers = nn.TransformerEncoderLayer(
            d_model=ff_dim, nhead=n_heads, dim_feedforward=ff_dim, dropout=dropout
        )
        self.transformer_encoder = nn.TransformerEncoder(encoder_layers, num_layers=num_layers)
        
        # RNN (LSTM) components
        self.lstm = nn.LSTM(input_size=ff_dim, hidden_size=lstm_hidden_size, num_layers=lstm_num_layers, batch_first=True, dropout=dropout)
        
        # Classification layer
        self.dropout = nn.Dropout(p=dropout)
        self.classifier = nn.Sequential(
            nn.Linear(lstm_hidden_size, 32),
            nn.ReLU(),
            self.dropout,
            nn.Linear(32, n_classes)
        )
        
    def forward(self, x):
        x = self.input_layer(x)  # Linear projection
        x = x.unsqueeze(1)  # Add a sequence dimension (required for Transformer)
        
        # Transformer encoder
        x = self.transformer_encoder(x)
        
        # LSTM
        x, _ = self.lstm(x)
        x = x.mean(dim=1)  # Global average pooling over the sequence dimension
        
        # Classifier
        x = self.classifier(x)
        return x



# Hyperparameters
input_dim = X_selected.shape[1]
n_classes = 7  # Number of classes
n_heads = 2  # Reduced number of heads
ff_dim = 64  # Reduced feedforward dimension
lstm_hidden_size = 64  # Hidden size for LSTM
lstm_num_layers = 2  # Number of LSTM layers
dropout = 0.4  # Increased dropout
learning_rate = 1e-3
epochs = 50
k_folds = 5
weight_decay = 1e-3  # Increased L2 regularization

# Initialize the model, loss function, and optimizer
model = TransformerRNNModel(input_dim=input_dim, n_classes=n_classes, n_heads=n_heads, ff_dim=ff_dim, num_layers=2, lstm_hidden_size=lstm_hidden_size, lstm_num_layers=lstm_num_layers, dropout=dropout)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=learning_rate, weight_decay=weight_decay)


# Early stopping parameters
early_stopping_patience = 5

# K-Fold Cross-Validation
kf = KFold(n_splits=k_folds, shuffle=True, random_state=42)

# Metrics storage
fold_metrics = {
    'accuracy': [],
    'precision': [],
    'recall': [],
    'f1': [],
    'confusion_matrices': []
}

# Training function with early stopping
def train_model(model, train_loader, val_loader, criterion, optimizer, epochs=50, patience=5):
    model.train()
    best_val_loss = float('inf')
    patience_counter = 0
    for epoch in range(epochs):
        running_loss = 0.0
        for inputs, labels in train_loader:
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
        
        # Early stopping based on validation loss
        val_loss = validate_model(model, val_loader, criterion)
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0  # Reset patience counter if validation loss improves
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print(f"Early stopping at epoch {epoch + 1}")
                break
        
        print(f"Epoch {epoch+1}/{epochs}, Loss: {running_loss / len(train_loader)}, Val Loss: {val_loss}")

# Validation function to monitor validation loss for early stopping
def validate_model(model, val_loader, criterion):
    model.eval()
    val_loss = 0.0
    with torch.no_grad():
        for inputs, labels in val_loader:
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            val_loss += loss.item()
    return val_loss / len(val_loader)

# Evaluation function
def evaluate_model(model, test_loader):
    model.eval()
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for inputs, labels in test_loader:
            outputs = model(inputs)
            _, predicted = torch.max(outputs, 1)
            all_preds.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    
    return np.array(all_preds), np.array(all_labels)

# Perform K-Fold Cross Validation
for fold, (train_index, test_index) in enumerate(kf.split(X_tensor)):
    print(f'Fold {fold + 1}/{k_folds}')
    
    # Split data into training and test sets for this fold
    X_train, X_test = X_tensor[train_index], X_tensor[test_index]
    y_train, y_test = y_tensor[train_index], y_tensor[test_index]
    
    # Further split training data into train and validation sets for early stopping
    train_idx, val_idx = train_test_split(np.arange(len(X_train)), test_size=0.2, random_state=42)
    X_train_fold, X_val_fold = X_train[train_idx], X_train[val_idx]
    y_train_fold, y_val_fold = y_train[train_idx], y_train[val_idx]
    
    # Create DataLoader for batching
    train_dataset = TensorDataset(X_train_fold, y_train_fold)
    val_dataset = TensorDataset(X_val_fold, y_val_fold)
    test_dataset = TensorDataset(X_test, y_test)
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)
    
    # Reset model, criterion, and optimizer for each fold
    model = TransformerRNNModel(input_dim=input_dim, n_classes=n_classes, n_heads=n_heads, ff_dim=ff_dim, num_layers=2, lstm_hidden_size=lstm_hidden_size, lstm_num_layers=lstm_num_layers, dropout=dropout)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate, weight_decay=weight_decay)
    
    # Train the model with early stopping
    train_model(model, train_loader, val_loader, criterion, optimizer, epochs=epochs, patience=early_stopping_patience)
    
    # Evaluate the model
    y_pred, y_true = evaluate_model(model, test_loader)

    # Calculate metrics
    fold_accuracy = np.mean(y_pred == y_true)
    fold_precision = precision_score(y_true, y_pred, average='weighted')
    fold_recall = recall_score(y_true, y_pred, average='weighted')
    fold_f1 = f1_score(y_true, y_pred, average='weighted')
    fold_confusion_matrix = confusion_matrix(y_true, y_pred)
    
    fold_metrics['accuracy'].append(fold_accuracy)
    fold_metrics['precision'].append(fold_precision)
    fold_metrics['recall'].append(fold_recall)
    fold_metrics['f1'].append(fold_f1)
    fold_metrics['confusion_matrices'].append(fold_confusion_matrix)
    
    print(f'Fold {fold + 1} Accuracy: {fold_accuracy * 100:.2f}%')
    print(f'Fold {fold + 1} Precision: {fold_precision:.2f}')
    print(f'Fold {fold + 1} Recall: {fold_recall:.2f}')
    print(f'Fold {fold + 1} F1 Score: {fold_f1:.2f}')
    print(f'Fold {fold + 1} Confusion Matrix:\n{fold_confusion_matrix}')

# Print overall average metrics across all folds
avg_accuracy = np.mean(fold_metrics['accuracy'])
avg_precision = np.mean(fold_metrics['precision'])
avg_recall = np.mean(fold_metrics['recall'])
avg_f1 = np.mean(fold_metrics['f1'])

print(f'\nAverage Accuracy across {k_folds} folds: {avg_accuracy * 100:.2f}%')
print(f'Average Precision across {k_folds} folds: {avg_precision:.2f}')
print(f'Average Recall across {k_folds} folds: {avg_recall:.2f}')
print(f'Average F1 Score across {k_folds} folds: {avg_f1:.2f}')


# Evaluating on new test data (test.csv)
new_test_file_path = 'test.csv'  # Path to your new test data
test_data = pd.read_csv(new_test_file_path)

# Split features and target for new test data
X_test_new = test_data.drop(columns=['Target'])
y_test_new = test_data['Target']
y_test_new = y_test_new - 1  # Adjust target labels to be in the range [0, n_classes - 1]

# Apply the same feature selection and scaling as in training
X_test_new_selected = select_kbest_anova.transform(X_test_new)  # Apply feature selection to test data
X_test_new_scaled = scaler.transform(X_test_new_selected)  # Apply the same scaling

# Convert new test data to PyTorch tensors
X_test_new_tensor = torch.tensor(X_test_new_scaled, dtype=torch.float32)
y_test_new_tensor = torch.tensor(y_test_new.values, dtype=torch.long)

# Create a DataLoader for new test data
new_test_dataset = TensorDataset(X_test_new_tensor, y_test_new_tensor)
new_test_loader = DataLoader(new_test_dataset, batch_size=32, shuffle=False)

# Evaluation function to get predictions on the new test data
def evaluate_model_on_test(model, test_loader):
    model.eval()  # Set the model to evaluation mode
    all_preds = []
    all_labels = []
    with torch.no_grad():  # No need to calculate gradients for evaluation
        for inputs, labels in test_loader:
            outputs = model(inputs)
            _, predicted = torch.max(outputs, 1)  # Get the index of the max log-probability
            all_preds.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    
    return np.array(all_preds), np.array(all_labels)

# Evaluate the model on the new test data
y_pred_new, y_true_new = evaluate_model_on_test(model, new_test_loader)

# Calculate metrics for new test data
accuracy_new = np.mean(y_pred_new == y_true_new)
precision_new = precision_score(y_true_new, y_pred_new, average='weighted')
recall_new = recall_score(y_true_new, y_pred_new, average='weighted')
f1_new = f1_score(y_true_new, y_pred_new, average='weighted')
conf_matrix_new = confusion_matrix(y_true_new, y_pred_new)

# Print results for new test data
print(f"New Test Data Accuracy: {accuracy_new * 100:.2f}%")
print(f"New Test Data Precision: {precision_new:.2f}")
print(f"New Test Data Recall: {recall_new:.2f}")
print(f"New Test Data F1 Score: {f1_new:.2f}")
print(f"New Test Data Confusion Matrix:\n{conf_matrix_new}")
