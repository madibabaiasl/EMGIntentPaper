import pandas as pd
from sklearn.model_selection import train_test_split, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.metrics import f1_score, precision_score, recall_score, confusion_matrix, accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC


# Load the dataset
file_path = 'normalized_emg_dataset.csv'
data = pd.read_csv(file_path)

# Split the features and target for training
X = data.drop(columns=['Target'])
y = data['Target']
y = y - 1  # Adjust target labels to be in the range [0, n_classes - 1]

# Apply feature selection on training data
select_kbest_anova = SelectKBest(score_func=f_classif, k=20)
X_selected = select_kbest_anova.fit_transform(X, y)  # Fit only on training data

# Standardize the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_selected)

# Split data into training and validation sets
X_train, X_val, y_train, y_val = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Initialize models
models = {
    "Logistic Regression": LogisticRegression(),
    "Linear Discriminant Analysis (LDA)": LinearDiscriminantAnalysis(),
    "Naive Bayes": GaussianNB(),
    "Decision Tree": DecisionTreeClassifier(),
    "SVM (Linear Kernel)": SVC(kernel='linear', probability=True)
}

# Train models on training data
for model_name, model in models.items():
    print(f"Training {model_name}...")
    model.fit(X_train, y_train)

# Load the new test dataset (test.csv)
new_test_file_path = 'test.csv'
test_data = pd.read_csv(new_test_file_path)

# Split features and target for new test data
X_test_new = test_data.drop(columns=['Target'])
y_test_new = test_data['Target']
y_test_new = y_test_new - 1  # Adjust target labels to be in the range [0, n_classes - 1]

# Apply the same feature selection and scaling as in training
X_test_new_selected = select_kbest_anova.transform(X_test_new)  # Apply feature selection to test data
X_test_new_scaled = scaler.transform(X_test_new_selected)  # Apply the same scaling

# Evaluate each model on the new test data
print("\nEvaluating models on new test data...")
for model_name, model in models.items():
    # Make predictions on the new test data
    y_pred_new = model.predict(X_test_new_scaled)
    
    # Calculate metrics
    accuracy_new = accuracy_score(y_test_new, y_pred_new)
    precision_new = precision_score(y_test_new, y_pred_new, average='weighted')
    recall_new = recall_score(y_test_new, y_pred_new, average='weighted')
    f1_new = f1_score(y_test_new, y_pred_new, average='weighted')
    conf_matrix_new = confusion_matrix(y_test_new, y_pred_new)
    
    # Print results for each model
    print(f"{model_name} Results on New Test Data:")
    print(f"Accuracy: {accuracy_new * 100:.2f}%")
    print(f"Precision: {precision_new:.2f}")
    print(f"Recall: {recall_new:.2f}")
    print(f"F1 Score: {f1_new:.2f}")
    print(f"Confusion Matrix:\n{conf_matrix_new}")
    print("-" * 40)



# Load the new test dataset (test.csv)
new_test_file_path = 'test.csv'
test_data = pd.read_csv(new_test_file_path)

# Split features and target for new test data
X_test_new = test_data.drop(columns=['Target'])
y_test_new = test_data['Target']
y_test_new = y_test_new - 1  # Adjust target labels to be in the range [0, n_classes - 1]

# Apply the same feature selection and scaling as in training
X_test_new_selected = select_kbest_anova.transform(X_test_new)  # Apply feature selection to test data
X_test_new_scaled = scaler.transform(X_test_new_selected)  # Apply the same scaling

# Evaluate each trained model on the new test data
print("\nEvaluating models on new test data...")

# Assuming 'models' dictionary contains the trained models (replace with your model variable if different)
for model_name, model in models.items():
    # Make predictions on the new test data
    y_pred_new = model.predict(X_test_new_scaled)
    
    # Calculate metrics
    accuracy_new = accuracy_score(y_test_new, y_pred_new)
    precision_new = precision_score(y_test_new, y_pred_new, average='weighted')
    recall_new = recall_score(y_test_new, y_pred_new, average='weighted')
    f1_new = f1_score(y_test_new, y_pred_new, average='weighted')
    conf_matrix_new = confusion_matrix(y_test_new, y_pred_new)
    
    # Print results for each model
    print(f"{model_name} Results on New Test Data:")
    print(f"Accuracy: {accuracy_new * 100:.2f}%")
    print(f"Precision: {precision_new:.2f}")
    print(f"Recall: {recall_new:.2f}")
    print(f"F1 Score: {f1_new:.2f}")
    print(f"Confusion Matrix:\n{conf_matrix_new}")
    print("-" * 40)
